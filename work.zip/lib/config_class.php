<?php

class Config_class
{
    var $secret = "testwork";

    var $host = "localhost";
    var $db = "office5c_redsoft";
    var $user = "office5c_redsoft";
    var $password = "192837465Aa_";
}